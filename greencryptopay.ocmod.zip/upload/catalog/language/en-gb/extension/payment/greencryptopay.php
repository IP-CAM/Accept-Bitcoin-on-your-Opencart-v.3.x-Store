<?php

$_['text_title']      = 'Cryptocurrencies via Green Crypto Processing';
$_['button_confirm']  = 'Pay via Green Crypto Processing';
$_['notification_subject']  = 'Order paid';
$_['notification_text_start']  = 'Order № ';
$_['notification_text_end']  = ' paid through the Green Crypto Processing service';